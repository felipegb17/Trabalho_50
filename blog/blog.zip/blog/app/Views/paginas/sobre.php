<div class="container my-3">
    <div class="card">
        <div class="card-body">
            <h1 class="my-3"><?= $dados['titulo'] ?></h1>

            <p><b>O que você aprenderá?</b></p>

            <ul class="list-group list-group-flush">
                <li class="list-group-item">Nestas aulas vamos aprender a construir aplicações PHP com MVC e utilizar o git como repositório</li>

            </ul>
        </div>
    </div>

</div>