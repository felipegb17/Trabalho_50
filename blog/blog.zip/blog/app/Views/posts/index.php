<h1><?= $dados['titulo'] ?></h1>
<h2><?= $dados['descricao'] ?></h2>