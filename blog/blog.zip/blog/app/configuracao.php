<?php

define('APP', dirname(__FILE__));
define('URL', 'http://localhost/blog');
define('APP_NOME','Aula de PHP Orientado a Objetos Com MVC');

//outra forma de declarar constante
const APP_VERSAO = '1.0.0';